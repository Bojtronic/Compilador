package Logica;

import Objetos.Datos;
import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.File;
import java.io.FileReader;
import java.io.FileWriter;
import java.io.IOException;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.Paths;
import java.nio.file.StandardCopyOption;
import java.util.ArrayList;
import java.util.Collections;
import java.util.Formatter;
import java.util.StringTokenizer;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

/**
 *
 * @author Karla
 */

public class Funciones {

    //Declaración de variables. 
    public static String nombreValidado = "";
    String nombreArchivo = "";
    File archivo;
    BufferedReader archivoLeer;
    BufferedWriter escribirArchivo;

    //Array con el contenido original del file_Archivo
    ArrayList<String> lista_ContenidoOriginal = new ArrayList<String>();

    //Array  sin comentarios del file_Archivo
    ArrayList<String> lista_ContenidoLimpio = new ArrayList<String>();

    //Array  para imprimir en file_Archivo de errores
    ArrayList<String> lista_ContenidoConErrores = new ArrayList<String>();

    //ArrayList tipo variables 
    ArrayList<String> lista_TiposDeVariables = new ArrayList<String>();  
    
    //ArrayList para lineas originales
    ArrayList<Datos> lista_Original = new ArrayList<Datos>(); 
    
    //ArrayList para lineas con errores
    ArrayList<Datos> arregloConErrores = new ArrayList<Datos>(); 

    //Declaración de arrays para palabras o comandos especiales
    ArrayList<String> lista_PalabrasReservadas = new ArrayList<String>(); //ArrayList donde estaran las palabras reservadas de ALGOL   
    ArrayList<String> lista_PalabrasReservadasMayus = new ArrayList<String>(); //ArrayList donde estaran las palabras reservadas de ALGOL en mayuscula  
    ArrayList<String> lista_Comandos = new ArrayList<>();

    String ruta = Paths.get("").toAbsolutePath().toString();


    //Constructor
    public Funciones() {
        //Se llena el ArrayList con las palabras reservadas de ALGOL
        Collections.addAll(lista_PalabrasReservadas, "ABS", "AND", "ARG", "BEGIN", "BIN", "BITS", "BOOL", "BYTES", "CHANNEL", "CHAR", "COMMENT", "COMPL", "COMPLEX", "CONJ", "DET", "DIVAB", "DO", "DOUBLE", "DOWN", "DYAD", "ELEM", "ELSIF", "END", "ENTIER", "EQ", "FALSE",
                "FILE", "FLEX", "FORMAT", "GE", "GT", "IM", "INT", "INV", "LE", "LENG", "LIBRARY", "LONG", "LT", "LWB", "MINUSAB", "MOD", "MODAB", "MODE", "NE", "NIL", "NORM", "NOT", "ODD", "OP", "OR", "OVER", "OVERAB", "PIPE", "PLUSAB", "PLUSTO", "PR", "PRAGMAT", "PRELUDE",
                "PRIO", "PROC", "RE", "REAL", "REF", "REPEAT", "REPR", "ROUND", "ROW", "RETURN", "SEMA", "SHL", "SHORT", "SHORTEN", "SHR", "SIGN", "SKIP", "SOUND", "STANDARD", "STRING", "STRUCT", "TIMESAB", "TRACE", "TRUE", "TRANSPUT", "UP", "UPB", "VOID", "WHILE", "XOR", "a68g",
                "abend", "abort", "abs", "airy", "alnum", "alpha", "angle", "arccos", "arccosh", "arcsin", "arcsinh", "arctan", "arctan2", "arctanh", "argc", "argv", "aspect", "associate", "back", "background", "backspace", "bessel", "beta", "bin", "blank", "break", "channel",
                "cholesky", "circle", "clear", "clock", "close", "cntrl", "collect", "collections", "colour", "columns", "cos", "cosh", "cpu", "create", "curses", "curt", "debug", "digit", "draw", "elliptic", "eof", "eoln", "erase", "erf", "error", "establish", "evaluate", "execve",
                "exp", "factorial", "fft", "fill", "fixed", "flip", "float", "flop", "font", "fork", "format", "gamma", "garbage", "gc", "get", "getchar", "getf", "graph", "grep", "halt", "heap", "http", "idf", "in", "incomplete", "integral", "inverse", "is", "last",
                "lengths", "line", "linestyle", "linewidth", "ln", "local", "lock", "log", "lower", "lu", "make", "max", "min", "mksa", "modes", "move", "name", "new", "null", "num", "on", "open", "out", "pack", "page", "pi", "point", "pointer", "possible",
                "preemptive", "print", "printf", "punct", "put", "putchar", "putf", "qr", "random", "read", "rect", "refresh", "reidf", "reset", "resolution", "return", "routine", "scratch", "seconds", "set", "shorths", "show", "sin", "sinh", "size", "size = INT",
                "small", "sound", "space", "sqrt", "stack", "stand", "stop", "style", "sub", "sv", "sweep", "system", "tan", "tanh", "tcp", "term", "text", "time", "upper", "value", "wait", "whole", "width", "will", "window", "write", "xdigit");
        //Se llena el ArrayList con las palabras reservadas de ALGOL en mayuscula
        Collections.addAll(lista_PalabrasReservadasMayus, "ABS", "AND", "ARG", "BEGIN", "BIN", "BITS", "BOOL", "BYTES", "CHANNEL", "CHAR", "COMMENT", "COMPL", "COMPLEX", "CONJ", "DET", "DIVAB", "DO", "DOUBLE", "DOWN", "DYAD", "ELEM", "ELSIF", "END", "ENTIER", "EQ", "FALSE",
                "FILE", "FLEX", "FORMAT", "GE", "GT", "IM", "INT", "INV", "LE", "LENG", "LIBRARY", "LONG", "LT", "LWB", "MINUSAB", "MOD", "MODAB", "MODE", "NE", "NIL", "NORM", "NOT", "ODD", "OP", "OR", "OVER", "OVERAB", "PIPE", "PLUSAB", "PLUSTO", "PR", "PRAGMAT", "PRELUDE",
                "PRIO", "PROC", "RE", "REAL", "REF", "REPEAT", "REPR", "ROUND", "ROW", "RETURN", "SEMA", "SHL", "SHORT", "SHORTEN", "SHR", "SIGN", "SKIP", "SOUND", "STANDARD", "STRING", "STRUCT", "TIMESAB", "TRACE", "TRUE", "TRANSPUT", "UP", "UPB", "VOID", "WHILE", "XOR");
        //Se llena arraylist con tipos de variables. 
        Collections.addAll(lista_TiposDeVariables, "CHAR", "INT", "REAL");

        Collections.addAll(lista_Comandos, "BEGIN", "read", "print", "FOR", "IF", "GOTO", "SKIP", "END", "DO", "OD", "FI", "ELSE");
    }

    //Getter and Setter
    public String getArchivo() {
        return nombreArchivo;
    }

    public void setArchivo(String archivo) {
        this.nombreArchivo = archivo;
    }


    //Ejecución principal
    public void iniciarValidaciones() {
        verificar_Comentarios();
        verificar_BeginEnd();
        verificar_Advertencias();
        verificar_LargoLinea();
        verificar_PalabrasReservadas();
        verificar_Variables();
        verificar_Multilineas();
        if (!arregloConErrores.isEmpty()) {
            if (revisar_Errores()) {
                MostrarDatos();
                crearArchivo();
                abrirArchivoErrores();
            } else {
                MostrarDatos();
                crearArchivo();
                abrirArchivoErrores();
                invocarCompiladorAlgol();
            }
        } else {
            invocarCompiladorAlgol();
        }
    }
  

    //Métodos de validación
    // Validaciones sobre el nombre del archivo. 
    public boolean validarNombreArchivo(String nombre) {
        int contador = 1;
        String[] dividirNombre = new String[10];
        boolean verificar = true, valido = true;
        
        if (verificar) {
            dividirNombre = nombre.split("\\.");
            if (dividirNombre[0].length() > 20) {
                Datos miError = new Datos(contador, true, "Error, el nombre del archivo contiene más de 20 caracteres");
                arregloConErrores.add(miError);
                contador++;
                valido = false; //bandera
            }
        }
        
        if ((verificar = regex("^[0-9]", nombre)) == true) {
            Datos miError = new Datos(contador, true, "Error, el nombre del archivo inicia con número");
            arregloConErrores.add(miError);
            contador++;
            valido = false; //bandera
            //No usar otros caracteres especiales, si acepta puntos
        }
        
        if ((verificar = regex("[^\\w\\.]", nombre)) == true) {
            Datos miError = new Datos(contador, true, "Error, el nombre del archivo tiene caracteres especiales");
            arregloConErrores.add(miError);
            contador++;
            valido = false; //bandera
            //No iniciar con guion bajo
        }
        
        if ((verificar = regex("^_", nombre)) == true) {
            Datos miError = new Datos(contador, true, "Error, el nombre del archivo empieza con un _");
            arregloConErrores.add(miError);
            contador++;
            valido = false; //bandera
            //No terminar con guion bajo   
        }
        
        if ((verificar = regex("_$", nombre)) == true) {
            Datos miError = new Datos(contador, true, "Error, el nombre del archivo termina con un _");
            arregloConErrores.add(miError);
            contador++;
            valido = false; //bandera
            //verificar la extension del archivo
        }
        
        if ((verificar = regex("\\.MINGOL$", nombre) == true) && (verificar = regex("\\.{2,}", nombre) == true)) {
            Datos miError = new Datos(contador, true, "Error, el nombre del archivo tiene dos puntos o más");
            arregloConErrores.add(miError);
            contador++;
            valido = false; //bandera
        }
        
        if ((verificar = regex("\\.$", nombre)) == true) {
            Datos miError = new Datos(contador, true, "Error, el nombre termina en punto y no tiene extension");
            arregloConErrores.add(miError);
            contador++;
            valido = false; //bandera
        }
        
        //si tiene extension diferente de MINGOL o mingol
        if ((verificar = regex("\\.(?:mingol$|MINGOL$)", nombre) == false) && (verificar = regex("\\.(\\w+)", nombre) == true)) {
            Datos miError = new Datos(contador, true, "Error, el nombre del archivo tiene una extensión inválida");
            arregloConErrores.add(miError);
            contador++;
            valido = false; //bandera
        }
        
        //si es valido y tiene extension correcta, solo lo asignamos a la variable estatica global
        if ((valido == true) && ((verificar = regex("\\.MINGOL$", nombre)) == true)) {
            nombreValidado = nombre;
        }
        
        //si tiene un .mingol lo pasamos a .MINGOL
        if ((verificar = regex("\\.mingol$", nombre) == true)) {
            nombreValidado = nombre.replace(".mingol", ".MINGOL");
        }
        
        //si no tiene extension y es un nombre valido, le agregamos .MINGOL
        if ((valido == true) && ((verificar = regex("\\.$", nombre)) == false) && ((verificar = regex("\\.(?:mingol$|MINGOL$)", nombre)) == false)) {
            nombreValidado = nombre + ".MINGOL";
        }
        
        return valido;
    }

    //Método para verificar el largo de una línea
    public void verificar_LargoLinea() {
        int contador = 0;
        for (String linea : lista_ContenidoLimpio) {
            if (linea.length() > 80) {
                Datos lineaError = new Datos(contador, true, "Error 00010: Línea excede cantidad máxima de caracteres.");
                arregloConErrores.add(lineaError);
            }
            contador++;
        }
    }

    //Método validar comentarios
    public void verificar_Comentarios() {
        ArrayList<String> contenidoCopia = new ArrayList<String>();
        contenidoCopia = (ArrayList<String>) lista_ContenidoOriginal.clone();

        boolean bandera = false;
        String aux = "";
        int contador = 0;

        for (String linea : contenidoCopia) {
            aux = "";
            linea = linea.replaceAll("\\s+", " ").trim();
            String[] palabras = dividirCadenaTokens(linea);
            int cantidadComentarios = 0;

            // Conteo de cantidad de palabra reservada para comentario en una línea.
            for (int i = 0; i < palabras.length; i++) {
                if (regex("\\bCOMMENT\\b\\w*|\\bCO\\b\\w*|#\\w*", palabras[i])) {
                    cantidadComentarios++;
                }
            }

            // Valida que haya palabra reservada de comentario.
            if (!bandera && regex("\\bCOMMENT\\b\\w*|\\bCO\\b\\w*|#\\w*", linea)) {
                // Valida que el comentario inicie y cierre en la misma línea.
                // Inicia un comentario de una única línea.
                if (!bandera && regex("^\\bCOMMENT\\b|^\\bCO\\b|^[#]", linea) && regex("\\bCOMMENT\\b$|\\bCO\\b$|[#]$", linea) && palabras.length > 1) {
                    // Inicia y termina un comentario de una única línea.
                    lista_ContenidoLimpio.add(aux);
                } else if (!bandera && regex("^\\bCOMMENT\\b|^\\bCO\\b|^[#]", linea)) {
                    // Inicia un comentario multilínea.
                    lista_ContenidoLimpio.add(aux);
                    bandera = !bandera;
                } else {
                    // Una palabra reservada de comentario tiene texto antes, ej: text COMMENT.
                    lista_ContenidoLimpio.add(linea);
                    Datos lineaError = new Datos(contador, true, "Error 00010: Comentario con texto antecedente.");
                    arregloConErrores.add(lineaError);
                }
            } else if (bandera && regex("\\bCOMMENT\\b$|\\bCO\\b$|[#]$", linea)) {
                if (cantidadComentarios == 1) {
                    // Cierre correcto de comentario. 
                    bandera = !bandera;
                    lista_ContenidoLimpio.add(aux);
                } else {
                    // Cierre incorrecto de comentario. 
                    bandera = !bandera;
                    lista_ContenidoLimpio.add(linea);
                    Datos lineaError = new Datos(contador, true, "Error 00010: Mal cierre de comentario.");
                    arregloConErrores.add(lineaError);
                }
            } else if (bandera) {
                // Línea comentada con comentario de múltiple línea. 
                lista_ContenidoLimpio.add(aux);
            } else {
                // Línea regular sin comentario. 
                lista_ContenidoLimpio.add(linea);
            }
            contador++;
        }
    }

    //Método validar BEGIN y END
    public void verificar_BeginEnd() {
        String aux = "";
        for (String linea : lista_ContenidoLimpio) {
            if (linea != "") {
                aux = aux + linea + " ";
            }
        }
        aux = aux.replaceAll("\\s+", " ").trim();

        if (!regex("^\\bBEGIN\\b", aux) || !regex("\\bEND\\b$", aux)) {
            Datos lineaError = new Datos(lista_ContenidoLimpio.size(), true, "Error 00101: Declaración erronea de BEGIN y END.");
            arregloConErrores.add(lineaError);
        }
    }

    //Método para validar las palabras reservadas de ALGOL
    public void verificar_Advertencias() {
        int contador = 0;

        //Se recorre los elementos del ArrayList
        for (String texto : lista_ContenidoLimpio) {
            String[] palabras = dividirCadenaTokens(texto); //Para obtener los token del elemento que se esta leyendo
            out:
            for (String palabra : palabras) { //Se recorren las palabras que tienen cada linea
                //Se recorren las palabras reservadas que están en la lista para comparar
                for (String palabraReservada : lista_PalabrasReservadas) {
                    //Se compara la cada palabra de cada linea con las palabras reservadas que están en la lista
                    if (palabra.equals(palabraReservada)) {
                       Datos lineaError = new Datos(contador, false, "Advertencia: " + "(" + palabra + ")" + " instrucción no es soportada por esta versión.");
                        arregloConErrores.add(lineaError);
                        break out; //Se rompe el ciclo al encontrar una palabra reservada
                    }
                }
            }
            contador++;
        }
    }

    //Método para validación de palabras reservadas. 
    public void verificar_PalabrasReservadas() {
        int contador = 0;
        for (String linea : lista_ContenidoLimpio) {
            String[] palabras = dividirCadenaTokens(linea); //Para obtener los token del elemento que se esta leyendo
            for (String palabra : palabras) { //Se recorren las palabras que tienen cada linea
                //Indices
                int indice = lista_PalabrasReservadas.indexOf(palabra);
                int indice2 = lista_PalabrasReservadasMayus.indexOf(palabra.toUpperCase());
                int indice3 = lista_PalabrasReservadas.indexOf(palabra.toLowerCase());

                if (indice != -1) {
                } else {
                    if (indice2 != -1) {
                       Datos lineaError = new Datos(contador, true, "Error 00010: " + "(" + palabra + ")" + " debe de ir en mayúscula.");
                        arregloConErrores.add(lineaError);
                    }
                    if (indice3 != -1) {
                      Datos lineaError = new Datos(contador, true, "Error 00011: " + "(" + palabra + ")" + " debe de ir en minúscula.");
                        arregloConErrores.add(lineaError);
                    }
                }
            }
            contador++;
        }
    }

    //Método para validación de variables y puntos y comas. 
    public void verificar_Variables() {
        int contador = 0;
        for (String linea : lista_ContenidoLimpio) {
            if ((linea == "") || linea.isEmpty() || (linea == " ")) {
                //ignorar lineas en blanco
            } else {
                linea = linea.replace(" ;", "; ");
                linea = linea.replace(" ,", ", ");
                //tokenizar palabras
                StringTokenizer tokens = new StringTokenizer(linea, " ");
                String[] datos = dividirCadenaTokens(linea);
                if (datos.length != 0) {
                    int indice1 = lista_TiposDeVariables.indexOf(datos[0]); //la variable debe iniciar en posicion 0
                    int indice2 = 0;
                    String token = "";
                    if (indice1 != -1) {
                        for (int i = 1; i < datos.length; i++) { //iniciamos en 1 porque no ocupamos revisar INT|CHAR|REAL
                            //validamos que no sea linea vacia
                            if (datos[i].isEmpty() || datos[i] == "" || datos[i] == " ") {
                                //ignorar
                            } else {
                                //busqueda palabra reservada
                                token = datos[i].trim();
                                token = datos[i].replaceAll("\\p{Punct}", "");
                                indice2 = lista_PalabrasReservadas.indexOf(token); //verificamos que no sea una variable que tenga formato de palabra reservada
                                if (indice2 != -1) {
                                    System.out.println();
                                    Datos lineaError = new Datos(contador, true, "Error 00101: " + token + " no puede ser variable porque es una palabra reservada.");
                                    arregloConErrores.add(lineaError);
                                } else {
                                    //validamos el ultimo elemento:
                                    if (i == datos.length - 1) {
                                        //que sea variable con punto y coma y que no sea punto y coma suelto
                                        if (!(regex("^(\\s+|)((?<name>[\\da-z_]+)(\\s+|);(\\s+|))$", datos[i])) && !(regex("(^(\\s+|);(\\s+|)$)", datos[i]))) {
                                            Datos lineaError = new Datos(contador, true, "Error 00090: " + "(" + datos[i] + ")" + " debe terminar con punto y coma o debe tener un único punto y coma.");
                                            arregloConErrores.add(lineaError);
                                        }
                                    } else {
                                        //que sea variable con coma, que no sea variable con punto y coma, que no sea coma suelta ni punto y coma suelto
                                        if (!(regex("^(\\s+|)((?<name>[\\da-z_]+)(\\s+|),(\\s+|))$", datos[i])) && !(regex("(^(\\s+|),(\\s+|)$)", datos[i])) && !(regex("(^(\\s+|);(\\s+|)$)", datos[i]))) {
                                            Datos lineaError = new Datos(contador, true, "Error 00091: " + "(" + datos[i] + ")" + " debe terminar con coma o debe tener una única coma.");
                                            arregloConErrores.add(lineaError);
                                        }
                                    }
                                    
                                    //verificar comas sueltas
                                    if ((regex("(^(\\s+|),(\\s+|)$)", datos[i]))) {
                                        if (((datos.length - 2) % 0 == 1)) {
                                            //no tiene comas de más                   
                                        } else {
                                           Datos lineaError = new Datos(contador, true, "Error 00092: " + "(" + datos[i] + ")" + " no debe tener comas guindando.");
                                            arregloConErrores.add(lineaError);
                                        }
                                    }
                                    
                                    //verificar puntos y comas sueltos
                                    if ((regex("(^(\\s+|);(\\s+|)$)", datos[i]))) {
                                        Datos lineaError = new Datos(contador, true, "Error 00093: " + "(" + datos[i] + ")" + " no debe tener puntos y comas guindando.");
                                        arregloConErrores.add(lineaError);
                                    }
                                    
                                    //verificar que no inicie CON _
                                    if ((regex("(^(_)([\\da-z_]+))", datos[i]))) {
                                        Datos lineaError = new Datos(contador, true, "Error 00094: " + "(" + datos[i] + ")" + " no debe iniciar con guión bajo.");
                                        arregloConErrores.add(lineaError);
                                    }
                                    
                                    //verificar que no termine con _
                                    if ((regex("(([\\da-z_]+)(_)$)", datos[i]))) {
                                     Datos lineaError = new Datos(contador, true, "Error 00095: " + "(" + datos[i] + ")" + " no debe terminar con guión bajo.");
                                        arregloConErrores.add(lineaError);
                                    }
                                }
                            }
                        }
                    }
                }
            }
            contador++;
        }
    }

    //Método para validar Multilineas
    public void verificar_Multilineas() {
        int contador = 0;
        int comandos_encontrados = 0;

        //Mientras que la línea de texto que se va leyendo sea diferente de null
        for (String linea : lista_ContenidoLimpio) {
            contador++;
            String[] palabras = dividirCadenaTokens(linea); //Para obtener los token de la linea que se esta leyendo
            for (String palabra : palabras) {
                //Se recorre el arreglo de palabras
                for (String comandos : lista_Comandos) {
                    if (palabra.equals(comandos)) {
                        comandos_encontrados++;
                    }
                }
                
                //Si el token es igual al COMANDO IF y lleva THEN + ;
                if (palabra.equals("IF") && linea.contains("THEN")) {
                    if (linea.contains(";")) {
                      Datos lineaError = new Datos(contador, false, "Error: " + "La instrucción  (" + palabra + ")" + " no debe llevar punto y coma.");
                        arregloConErrores.add(lineaError);
                    }
                }
                
                //Si el token es igual al COMANDO GOTO O ELSE y lleva ;
                if (palabra.contains("GOTO") || palabra.contains("ELSE")) {
                    if (linea.contains(";")) {
                     Datos lineaError = new Datos(contador, false, "Error: " + "El comando (" + palabra + ")" + " no debe llevar punto y coma.");
                        arregloConErrores.add(lineaError);
                    }
                }
                
                //Si el token es igual al COMANDO OD o FI y no lleva ;
                if (palabra.contains("OD") || palabra.contains("FI")) {
                    if (!linea.contains(";")) {
                       Datos lineaError = new Datos(contador, false, "Error: " + "El comando (" + palabra + ")" + " debe llevar punto y coma al final.");
                        arregloConErrores.add(lineaError);
                    }
                }
                
                //Si el token es igual al COMANDO DO
                if (palabra.equals("DO") && !linea.equals("DO")) {
                 Datos lineaError = new Datos(contador, false, "Error: " + "En la línea el comando (" + palabra + ")" + " no debe llevar punto y coma o algo adicional.");
                    arregloConErrores.add(lineaError);
                }
                
                //VALIDAMOS QUE SI SE ENCUENTRA AL COMANDO BEGIN NO DEBE CONTENER ; O ALGO ADICIONAL
                if (palabra.equals("BEGIN") && !linea.equals("BEGIN")) {
                  Datos lineaError = new Datos(contador, false, "Error: " + "En la línea el comando (" + palabra + ")" + " no debe llevar punto y coma o algo adicional.");
                    arregloConErrores.add(lineaError);
                }
                
                //VALIDAMOS QUE SI SE ENCUENTRA AL COMANDO END NO DEBE CONTENER ; O ALGO ADICIONAL
                if (palabra.equals("END") && !linea.equals("END")) {
                   Datos lineaError = new Datos(contador, false, "Error: " + "En la línea el comando (" + palabra + ")" + " no debe llevar punto y coma o algo adicional.");
                    arregloConErrores.add(lineaError);
                }
            }
            if (comandos_encontrados >= 2) {
                Datos lineaError = new Datos(contador, true, "Error, en la línea " + contador + " hay " + comandos_encontrados + " comandos repetidos");
                arregloConErrores.add(lineaError);
            }
            comandos_encontrados = 0;
        }
    }


    //Método para leer el archivo y almacenar la informacion en un ArrayList
    public void guardarOrg(String pRuta) {
        String texto;
        try {
            String aux = pRuta + "\\" + nombreValidado;
            archivo = new File(aux); //Se le pasa la ruta al objeto File
            //Se crea el bufferedReader
            archivoLeer = new BufferedReader(new FileReader(archivo));
            while ((texto = archivoLeer.readLine()) != null) { //Se recorre el archivo linea por linea
                lista_ContenidoOriginal.add(texto); //Se agrega el contenido del archivo a un arrayList
            }
            archivoLeer.close(); //Se cierra la lectura
        } catch (IOException e) {
            System.out.println("Error al leer archivo." + e);
        }
    }

    //Método para mostrar de los errores para el archivo. 
    public void imprimirErroresNombreArchivo(String ruta) throws IOException {
        //imprimimos en pantalla arreglo con errores, despues lo quitamos
        System.out.println("\nErrores encontrados:");
        for (Datos lineaError : arregloConErrores) {
            System.out.println(formatoInt(lineaError.getNumero_Linea()) + "\t" + lineaError.getInformacion_Linea());
        }
    }

    //Impresión de datos. 
    public void MostrarDatos() {
        int contador = 0;
        System.out.println("Nombre de archivo: " + nombreValidado);
        //imprimimos en pantalla arreglo original
        System.out.println("\nContenido Original");
        for (String miLinea : lista_ContenidoOriginal) {
            System.out.println(formatoInt(contador) + " " + miLinea);
            contador++;
        }
        //imprimimos en pantalla arreglo con errores
        System.out.println("\nErrores encontrados:");
        for (Datos lineaError : arregloConErrores) {
            System.out.println(formatoInt(lineaError.getNumero_Linea()) + " " + lineaError.getInformacion_Linea());
        }

        //imprimimos en pantalla arreglo con errores
        System.out.println("\n\nCombinación de Contenido Original y Errores:");
        contador = 0;
        for (String miLinea : lista_ContenidoOriginal) {
            System.out.println(formatoInt(contador) + " " + miLinea);
            lista_ContenidoConErrores.add(formatoInt(contador) + " " + miLinea);
            //mandamos a buscar la linea por el indice
            for (int i = 0; i < arregloConErrores.size(); i++) {
                if (arregloConErrores.get(i).numero_Linea == contador) {
                    //encontro un error_Linea, imprimalo
                    //si tiene muchos errores esa linea imprimiria todos los que encuentre
                    System.out.println(arregloConErrores.get(i).informacion_Linea);
                    lista_ContenidoConErrores.add(arregloConErrores.get(i).informacion_Linea);
                }
            }
            contador++;
        }
    }

    //Método para validar si hay algún error_Linea registrado. 
    public boolean revisar_Errores() {
        for (Datos linea : arregloConErrores) {
            if (linea.error_Linea) {
                return linea.error_Linea;
            }
        }
        return false;
    }

    //Método para crear el archivo
    public void crearArchivo() {
        File archivoErrores = new File(nombreValidado.substring(0, nombreValidado.indexOf(".")) + "-errores.txt");
        try {
            FileWriter guardar = new FileWriter(archivoErrores);
            for (String linea : lista_ContenidoConErrores) {
                guardar.write(linea + "\n");
            }
            guardar.close();
        } catch (Exception e) {
        }
    }

    //Método para abrir el archivo
    public void abrirArchivoErrores() {
        Runtime rs = Runtime.getRuntime();
        try {
            rs.exec("notepad " + Paths.get("").toAbsolutePath().toString() + "\\" + nombreValidado.substring(0, nombreValidado.indexOf(".")) + "-errores.txt");
        } catch (IOException e) {
            System.err.println("\n¡Se ha presentado un error!: " + e);
        }
    }

    //Método que ejecuta el compilador 
    public void invocarCompiladorAlgol() {
        String nombreAlgol = nombreValidado.replace(".MINGOL", ".a68");
        String pathFile = ruta + "\\" + nombreAlgol; //Se le agrega a la ruta el nombre del archivo a abrir
        String rutaOriginal = ruta + "\\" + nombreValidado;
        Path copied = Paths.get(pathFile);
        
        Path originalPath = Paths.get(rutaOriginal);
        
        try {
            Files.copy(originalPath, copied, StandardCopyOption.COPY_ATTRIBUTES);
        } catch (Exception e) {
        }

        String comando = ruta + "\\" + "a68g.exe " + pathFile; //Se guarda la ruta con el .exe que se va a abrir tomado en cuenta la ruta con el nombre del archivo
        try {
            //Se guarda el comando que se ejecutará en el cmd
            String[] comandoCmd = {"cmd.exe", "/c", "start", "cmd.exe", "/k", comando};
            //Se le pasa el comando del cmd al constructor de procesos
            ProcessBuilder pBuilder = new ProcessBuilder(comandoCmd);
            //Se crea un proceso para abrir el archivo recibido por parametro
            Process proceso = pBuilder.start();
        } catch (IOException e) {
            System.out.println("Se ha producido un error." + e);
        }
    }

    //regex, recibe por argumento el pattern y la variable a validar
    private boolean regex(String patron, String variable) {
        Pattern pattern = Pattern.compile(patron);
        Matcher matcher = pattern.matcher(variable);
        boolean matchFound = matcher.find();
        if (matchFound) {
            return true;
        }
        return false;
    }

    //Método que divide una cadena en tokens
    public String[] dividirCadenaTokens(String cadena) {
        String[] tokens = cadena.split(" ");
        return tokens;
    }

    //Formato con ceros para número de índice
    public static String formatoInt(int num) {
        Formatter obj = new Formatter();
        return String.valueOf(obj.format("%05d", num));
    }
}
