/*      UNIVERSIDAD ESTATAL A DISTANCIA
   Curso:  Compiladores
   Código: 03307
   Tarea 2
   Tutora: Elluany Fiorella Calvo Rojas
   Grupo: 05
   Estudiante: Karla Bricelda Aguilar González
   Cédula: 155825898214
   I Cuatrimestre 2022
   Fecha de Inicio: 21 de marzo 2022
   Fecha de finalización: 27 de marzo 2022
 */

package Main;

import Logica.Funciones;
import java.io.IOException;
import java.nio.file.Paths;

/**
 *
 * @author Karla
 */

public class Principal {

    public static void main(String[] args) throws IOException {
        Funciones funcion = new Funciones();

        String ruta = Paths.get("").toAbsolutePath().toString();
        //Tomamos el primer argumento enviado por el cmd y lo pasamos a la variable
        try {
            //Si la persona ingresa espacios en blanco en el nombre, debe dar error porque args lo toma separado
            if (args.length > 1) {
                System.out.println("Error, el nombre del archivo no debe tener espacios en blanco");
            } else {
                String nombreArchivo = args[0];

                //Validar el nombre del archivo
                boolean abrirArchivo = funcion.validarNombreArchivo(nombreArchivo);

                if (abrirArchivo) {
                    funcion.guardarOrg(ruta);
                    funcion.iniciarValidaciones();                    
                } else {
                    System.out.println("Lo sentimos, el nombre del archivo es inválido, verifique los siguientes errores:");
                    System.out.println("Nombre de archivo procesado: " + nombreArchivo);
                    funcion.imprimirErroresNombreArchivo(ruta);
                }
            }
        } catch (IOException e) {
            //verificar si pasan una linea vacia o nula
            System.out.println("Error, no se indicó nombre del archivo o sólo ingresó espacios en blanco");
        }

    }
}
