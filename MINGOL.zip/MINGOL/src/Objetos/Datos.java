package Objetos;

/**
 *
 * @author Karla
 */

public class Datos {
        //DECLARACIÓN DE VARIABLES
    public int numero_Linea; // GUARDA EL NÚMERO DE LA LINEA QUE SIRVE COMO IDENTIFICADOR O LLAVE  EN LA BÚSQUEDA
    public boolean error_Linea;
    public  String informacion_Linea; //GUARDA LA INFORMACIÓN QUE PUEDE SER LA LINEA LEIDA O UN ERROR EN LA LINEA

    //CONSTRUCTOR
    public Datos(int numero_Linea, boolean error_Linea, String texto_Linea) {
        this.numero_Linea = numero_Linea;
        this.error_Linea = error_Linea;
        this.informacion_Linea = texto_Linea;
    }

    //GETTER DE LAS VARIABLES DECLARADAS
    public int getNumero_Linea() {
        return numero_Linea;
    }

    public boolean getError() {
        return error_Linea;
    }

    public String getInformacion_Linea() {
        return informacion_Linea;
    }
}